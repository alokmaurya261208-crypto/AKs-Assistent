package com.example.myofflineaichatbot;

import android.app.*;
import android.os.*;
import android.content.*;
import android.text.InputType;
import android.webkit.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private WebView webView;
    private final ExecutorService executor=Executors.newSingleThreadExecutor();
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        prefs=getSharedPreferences("ak_assistant",0);
        webView=new WebView(this);
        WebSettings s=webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        webView.addJavascriptInterface(new AIInterface(),"AndroidAI");
        webView.loadUrl("file:///android_asset/chatbot.html");
        setContentView(webView);
        if(prefs.getString("api_key","").isEmpty()) webView.postDelayed(this::showApiKeyDialog,500);
    }

    private void showApiKeyDialog(){
        EditText input=new EditText(this);
        input.setHint("gsk_..."); input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        new AlertDialog.Builder(this).setTitle("Groq API key")
        .setMessage("Enter your Groq API key. It is stored only on this phone.")
        .setView(input).setPositiveButton("Save",(d,w)->{
            String key=input.getText().toString().trim();
            if(!key.isEmpty()){prefs.edit().putString("api_key",key).apply(); sendJs("window.onKeyStatus&&window.onKeyStatus(true);");}
        }).setNegativeButton("Later",null).show();
    }

    public class AIInterface {
        @JavascriptInterface public void ask(String prompt){
            String key=prefs.getString("api_key","");
            if(key.isEmpty()){runOnUiThread(()->{sendJs("window.onAIResponse&&window.onAIResponse("+JSONObject.quote("No Groq API key is saved.")+");");showApiKeyDialog();});return;}
            executor.execute(()->{String r=callGroq(key,prompt);runOnUiThread(()->sendJs("window.onAIResponse&&window.onAIResponse("+JSONObject.quote(r)+");"));});
        }
    }

    private String callGroq(String key,String prompt){
        HttpURLConnection c=null;
        try{
            c=(HttpURLConnection)new URL("https://api.groq.com/openai/v1/chat/completions").openConnection();
            c.setRequestMethod("POST"); c.setConnectTimeout(20000); c.setReadTimeout(60000); c.setDoOutput(true);
            c.setRequestProperty("Content-Type","application/json"); c.setRequestProperty("Authorization","Bearer "+key);
            JSONObject body=new JSONObject(); body.put("model","openai/gpt-oss-20b");
            JSONArray msgs=new JSONArray(); JSONObject m=new JSONObject(); m.put("role","user"); m.put("content",prompt); msgs.put(m); body.put("messages",msgs);
            try(OutputStream o=c.getOutputStream()){o.write(body.toString().getBytes(StandardCharsets.UTF_8));}
            int code=c.getResponseCode();
            BufferedReader r=new BufferedReader(new InputStreamReader(code>=200&&code<300?c.getInputStream():c.getErrorStream(),StandardCharsets.UTF_8));
            StringBuilder out=new StringBuilder(); String line; while((line=r.readLine())!=null)out.append(line);
            if(code<200||code>=300)return "Groq error ("+code+"): "+out;
            JSONObject j=new JSONObject(out.toString()); JSONArray choices=j.optJSONArray("choices");
            if(choices!=null&&choices.length()>0){JSONObject ch=choices.optJSONObject(0); JSONObject msg=ch==null?null:ch.optJSONObject("message"); if(msg!=null)return msg.optString("content","");}
            return "I could not read the AI response.";
        }catch(Exception e){return "Connection error: "+e.getMessage();}finally{if(c!=null)c.disconnect();}
    }
    private void sendJs(String js){webView.evaluateJavascript(js,null);}
    @Override protected void onDestroy(){executor.shutdownNow();webView.destroy();super.onDestroy();}
}
